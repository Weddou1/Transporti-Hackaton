import 'package:flutter/material.dart';
import 'package:flutterapp/transportiapp/generatedacceuilwidget/GeneratedAcceuilWidget.dart';
import 'package:flutterapp/transportiapp/generatedpassagerwidget1/GeneratedPassagerWidget1.dart';
import 'package:flutterapp/transportiapp/generatedchauffeurloginwidget/GeneratedChauffeurLoginWidget.dart';
import 'package:flutterapp/transportiapp/generatedchauffeurinitwidget/GeneratedChauffeurInitWidget.dart';
import 'package:flutterapp/transportiapp/generatedchauffeurdirectionwidget/GeneratedChauffeurDirectionWidget.dart';
import 'package:flutterapp/transportiapp/generatedlistestationwidget/GeneratedListestationWidget.dart';
import 'package:flutterapp/transportiapp/generatedlistestationpwidget/GeneratedListestationPWidget.dart';

void main() {
  runApp(TRANSPORTIApp());
}

class TRANSPORTIApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedAcceuilWidget',
      routes: {
        '/GeneratedAcceuilWidget': (context) => GeneratedAcceuilWidget(),
        '/GeneratedPassagerWidget1': (context) => GeneratedPassagerWidget1(),
        '/GeneratedChauffeurLoginWidget': (context) =>
            GeneratedChauffeurLoginWidget(),
        '/GeneratedChauffeurInitWidget': (context) =>
            GeneratedChauffeurInitWidget(),
        '/GeneratedChauffeurDirectionWidget': (context) =>
            GeneratedChauffeurDirectionWidget(),
        '/GeneratedListestationWidget': (context) =>
            GeneratedListestationWidget(),
        '/GeneratedListestationPWidget': (context) =>
            GeneratedListestationPWidget(),
      },
    );
  }
}
